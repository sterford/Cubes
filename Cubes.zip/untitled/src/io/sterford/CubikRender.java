package io.sterford;

public class CubikRender {


    private static float A, B, C;
    private static float cubeWidth = 20;
    private static int width = 160, height = 44;
    private static float[] zBuffer = new float[width * height];
    private static char[] buffer = new char[width * height];
    private static int backgroundASCIICode = '.';
    private static int distanceFromCam = 100;
    private static float horizontalOffset;
    private static float K1 = 40;
    private static float incrementSpeed = 0.6f;

    private static float x, y, z;
    private static float ooz;
    private static int xp, yp;
    private static int idx;

    private static float calculateX(int i, int j, int k) {
        return j * (float) Math.sin(A) * (float) Math.sin(B) * (float) Math.cos(C) - k * (float) Math.cos(A) * (float) Math.sin(B) * (float) Math.cos(C) +
                j * (float) Math.cos(A) * (float) Math.sin(C) + k * (float) Math.sin(A) * (float) Math.sin(C) + i * (float) Math.cos(B) * (float) Math.cos(C);
    }

    private static float calculateY(int i, int j, int k) {
        return j * (float) Math.cos(A) * (float) Math.cos(C) + k * (float) Math.sin(A) * (float) Math.cos(C) -
                j * (float) Math.sin(A) * (float) Math.sin(B) * (float) Math.sin(C) + k * (float) Math.cos(A) * (float) Math.sin(B) * (float) Math.sin(C) -
                i * (float) Math.cos(B) * (float) Math.sin(C);
    }

    private static float calculateZ(int i, int j, int k) {
        return k * (float) Math.cos(A) * (float) Math.cos(B) - j * (float) Math.sin(A) * (float) Math.cos(B) + i * (float) Math.sin(B);
    }

    private static void calculateForSurface(float cubeX, float cubeY, float cubeZ, char ch) {
        x = calculateX((int) cubeX, (int) cubeY, (int) cubeZ);
        y = calculateY((int) cubeX, (int) cubeY, (int) cubeZ);
        z = calculateZ((int) cubeX, (int) cubeY, (int) cubeZ) + distanceFromCam;

        ooz = 1 / z;

        xp = (int) (width / 2 + horizontalOffset + K1 * ooz * x * 2);
        yp = (int) (height / 2 + K1 * ooz * y);

        idx = xp + yp * width;
        if (idx >= 0 && idx < width * height) {
            if (ooz > zBuffer[idx]) {
                zBuffer[idx] = ooz;
                buffer[idx] = ch;
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
        while (true) {

            for (int i = 0; i < 100; i++) {
                System.out.println();
            }


            for (int i = 0; i < width * height; i++) {
                buffer[i] = (char) backgroundASCIICode;
                zBuffer[i] = 0;
            }

            cubeWidth = 20;
            horizontalOffset = -2 * cubeWidth;
            // Первый куб
            for (float cubeX = -cubeWidth; cubeX < cubeWidth; cubeX += incrementSpeed) {
                for (float cubeY = -cubeWidth; cubeY < cubeWidth; cubeY += incrementSpeed) {
                    calculateForSurface(cubeX, cubeY, -cubeWidth, '@');
                    calculateForSurface(cubeWidth, cubeY, cubeX, '$');
                    calculateForSurface(-cubeWidth, cubeY, -cubeX, '~');
                    calculateForSurface(-cubeX, cubeY, cubeWidth, '#');
                    calculateForSurface(cubeX, -cubeWidth, -cubeY, ';');
                    calculateForSurface(cubeX, cubeWidth, cubeY, '+');
                }
            }

            cubeWidth = 10;
            horizontalOffset = 1 * cubeWidth;

            for (float cubeX = -cubeWidth; cubeX < cubeWidth; cubeX += incrementSpeed) {
                for (float cubeY = -cubeWidth; cubeY < cubeWidth; cubeY += incrementSpeed) {
                    calculateForSurface(cubeX, cubeY, -cubeWidth, '@');
                    calculateForSurface(cubeWidth, cubeY, cubeX, '$');
                    calculateForSurface(-cubeWidth, cubeY, -cubeX, '~');
                    calculateForSurface(-cubeX, cubeY, cubeWidth, '#');
                    calculateForSurface(cubeX, -cubeWidth, -cubeY, ';');
                    calculateForSurface(cubeX, cubeWidth, cubeY, '+');
                }
            }

            cubeWidth = 5;
            horizontalOffset = 8 * cubeWidth;

            for (float cubeX = -cubeWidth; cubeX < cubeWidth; cubeX += incrementSpeed) {
                for (float cubeY = -cubeWidth; cubeY < cubeWidth; cubeY += incrementSpeed) {
                    calculateForSurface(cubeX, cubeY, -cubeWidth, '@');
                    calculateForSurface(cubeWidth, cubeY, cubeX, '$');
                    calculateForSurface(-cubeWidth, cubeY, -cubeX, '~');
                    calculateForSurface(-cubeX, cubeY, cubeWidth, '#');
                    calculateForSurface(cubeX, -cubeWidth, -cubeY, ';');
                    calculateForSurface(cubeX, cubeWidth, cubeY, '+');
                }
            }


            for (int k = 0; k < width * height; k++) {
                System.out.print(k % width != 0 ? buffer[k] : '\n');
            }

            A += 0.05;
            B += 0.05;
            C += 0.01;
            Thread.sleep(180);
        }
    }
}
